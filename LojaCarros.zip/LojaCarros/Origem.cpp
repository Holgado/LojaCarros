#include <iostream>

#include "Carros.h"
#include "ListaCarros.h"
#include "Vendedor.h"
#include "ListaVendedor.h"
#include "Interface.h"

using namespace std;

int main() {

	//vector<Carro> vetCarros;  // Lista de carro, estoque
	//vector<Vendedor> vetVedores;
	Carro carro;
	ListaCarros *estoque = new ListaCarros();
	Vendedor vendedor;
	ListaVendedor vendedores;
	Interface menu;
	bool sair = false;
	int pos;

	while (!sair) {
		menu.imprimeMenu();
		if (menu.getOpcao() == 1) {
			carro.cadastrarCarro();
			estoque->lista.push_back(carro);
		}
		else if (menu.getOpcao() == 2) {
			vendedor.cadastraVendedor();
			vendedores.lista.push_back(vendedor);
		}
		else if (menu.getOpcao() == 3) {
			pos = menu.loginVendedor(vendedores);
			vendedores.lista.at(pos).fazerVenda(estoque);
			vendedores.lista.at(pos).cacularComissao();
		}
		else if (menu.getOpcao() == 4) {
			pos = menu.loginVendedor(vendedores);
			menu.mostrarEstoque(estoque);
		}
		else if (menu.getOpcao() == 5) {
			sair = true;
		}
		else {
			cerr << "Erro, op��o inv�lida";
		}
	}
	return 0;
} 