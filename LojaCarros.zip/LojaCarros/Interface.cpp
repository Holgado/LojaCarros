#include "Interface.h"

int Interface::getOpcao()
{
	return opcao;
}

int Interface::loginVendedor(ListaVendedor list)
{
	int id;
	system("cls");
	cout << "----------    MENU DE LOGIN   ----------" << endl;
	cout << "ID: " << endl;
	cin >> id;
	for (int i = 1; list.lista.size(); i++) {
		if (list.lista.at(i).getId() == id) {
			system("cls");
			cout << "----------    MENU DE LOGIN   ----------" << endl;
			cout << "Vendor encontrado";
			return i;
		}
	}
	cout << "----------    MENU DE LOGIN   ----------" << endl;
	cout << "Vendor n�o encontrado";
	return -1;
}

void Interface::setOpcao(int op)
{
	opcao = op;
}

void Interface::imprimeMenu()
{
	int op;
	cout << "----------    MENU DE PRINCIPAL   ----------" << endl;

	cout << " Op��es:" << endl;
	cout << endl;
	cout << " ( 1 ) Cadastrar um veiculos " << endl;
	cout << " ( 2 ) Cadastrar um novo vendedor " << endl;
	cout << " ( 3 ) Fazer uma venda " << endl;
	cout << " ( 4 ) Fazer uma pesquisa no estoque " << endl;
	cout << " ( 5 ) SAIR " << endl;
	cin >> op;
	setOpcao(op);
}

void Interface::mostrarEstoque(ListaCarros *list)
{
	cout << "----------    ESTOQUE   ----------" << endl;
	for (int i = 1; list->lista.size(); i++) {
		cout << "{" << endl;
		cout << "\t" << list->lista.at(i).getModelo() << endl;
		cout << "\t" << list->lista.at(i).getAno() << endl;
		cout << "\t" << list->lista.at(i).getMotor() << endl;
		cout << "\t" << list->lista.at(i).getCor() << endl;
		cout << "\t" << list->lista.at(i).getPlaca() << endl;
		cout << "\t" << list->lista.at(i).getPreco() << endl;
		cout << "}" << endl;
	}
}
