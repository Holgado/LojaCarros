#pragma once
#include <iostream>
#include <vector>
#include "Carros.h"


using namespace std;

class ListaCarros {
public:
	vector<Carro> lista;
};
