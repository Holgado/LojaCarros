#pragma once
#include <iostream>
#include <vector>
#include "Vendedor.h"


using namespace std;

class ListaVendedor {
public:
	vector<Vendedor> lista;
};
